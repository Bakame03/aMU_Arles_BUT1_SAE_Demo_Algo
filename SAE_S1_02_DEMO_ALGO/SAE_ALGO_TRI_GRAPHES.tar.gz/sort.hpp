#ifndef SORT_HPP
#define SORT_HPP

#include <vector>

void mySort(std::vector<int>& v);

#endif