#include "sort.hpp"
#include <algorithm> 

void mySort(std::vector<int>& v) {
    std::sort(v.begin(), v.end());
}